import numpy as np
from tabulate import tabulate

#5*5, 3bit/px >> 2^3 = 8 = 0 - 7
data = [5,3,1,0,1,0,2,1,0,5,1,5,0,1,2,4,2,6,2,1,6,2,0,1,5] 

## ----- 1. Find r -----
hist_process = {}
for i in data:       # Count the frequency of each value in data
    if i in hist_process:
        hist_process[i] += 1
    else:
        hist_process[i] = 1
hist_process.update({i: 0 for i in range(8) if i not in hist_process})  # Ensure all values from 0 to 7 are present
hist_process = dict(sorted(hist_process.items()))
print("Data Count:", hist_process, "\n")

## ----- 2. Fine P_r -----
hist_process = {i: {"P_R":round(j / len(data), 2)} for i, j in hist_process.items()}    # Calculate the probability of each value
print("P_r:", ", ".join(f"{i}:{hist_process[i]['P_R']}" for i in hist_process.keys()), "\n")

## ----- 3. Find CDF(r) -----
sum_prev = 0
for i in hist_process.keys():       # Calculate the CDF
    sum_prev = round(sum_prev + hist_process[i]["P_R"], 2)
    hist_process[i]["CDF_R"] = sum_prev
print("CDF(r):", ", ".join(f"{i}:{hist_process[i]['CDF_R']}" for i in hist_process.keys()), "\n")

## ----- 4. Find CDF(r)*7 -----
hist_process = {i: {"P_R": hist_process[i]["P_R"], 
                    "CDF_R": hist_process[i]["CDF_R"], 
                    "CDF_R*7": round(hist_process[i]["CDF_R"] * 7, 2)}      # Calculate CDF(r)*7
                    for i in hist_process.keys()}
print("CDF(r)*7:", ", ".join(f"{i}:{hist_process[i]['CDF_R*7']}" for i in hist_process.keys()), "\n")

## ----- 5. Find s -----
hist_process = {i: {"P_R": hist_process[i]["P_R"],
                    "CDF_R": hist_process[i]["CDF_R"],
                    "CDF_R*7": round(hist_process[i]["CDF_R"] * 7, 2),
                    "s": int(hist_process[i]["CDF_R*7"])}                   # Calculate s = Floor(CDF(r)*7)
                    for i in hist_process.keys()}
print("s:", ", ".join(f"{i}:{hist_process[i]['s']}" for i in hist_process.keys()), "\n")

## ----- Show Table Caluclations -----
table_data = [
    [i, hist_process[i]['P_R'], hist_process[i]['CDF_R'], hist_process[i]['CDF_R*7'], hist_process[i]['s']]
    for i in range(8)
]
print(tabulate(table_data, headers=["r", "P_R", "CDF_R", "CDF_R*7", "s"], tablefmt="grid"), "\n")

## ----- 6. Replacs data with s -----
hist_eq = [hist_process[i]["s"] for i in data]
print("Histogram Equalization Result:")
print(tabulate( [hist_eq[i:i+5] for i in range(0, len(hist_eq), 5)], tablefmt="grid"))

