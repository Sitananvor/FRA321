import cv2
import numpy as np
import matplotlib.pyplot as plt

# ---------- Sol1 ----------
def mixed(img):
    ## Adjusting Brightness and Contrast
    alpha, beta = 10, 30                               
    adj = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)     

    ## Contrast Limited Adaptive Histogram Equalization (CLAHE) on Lightness Channel
    lab = cv2.cvtColor(adj, cv2.COLOR_BGR2LAB)       
    L, A, B = cv2.split(lab)                               
    A = np.clip(A - 18, 0, 255)  
    clahe = cv2.createCLAHE(clipLimit=5, tileGridSize=(2,2))
    L2 = clahe.apply(L)             
    lab2 = cv2.merge([L2, A.astype(np.uint8), B])    
    clahe_img = cv2.cvtColor(lab2, cv2.COLOR_LAB2BGR)  
  
    ## Noise Reduction by Spatial Filtering
    den_img = cv2.fastNlMeansDenoisingColored(src=clahe_img, dst=None, h=5, hColor=3, templateWindowSize=7, searchWindowSize=21) 
    return den_img
            
# ---------- Sol2 Intensity Transformation Functions ----------
def contrast_stretch(img, min=1, max=99):
    out = np.zeros_like(img)
    for c in range(img.shape[2]):
        ch = img[:, :, c]
        p_low  = np.percentile(ch, min)
        p_high = np.percentile(ch, max)
        if p_high <= p_low:
            out[:, :, c] = ch
            continue
        stretched = (ch.astype(np.float32) - p_low) / (p_high - p_low)
        out[:, :, c] = np.clip(stretched, 0, 1) * 255.0
    return out.astype(np.uint8)

# ---------- Sol3 Global Histogram Equalization on Luma Channel ----------
def global_histogram_equalization(img):
    ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
    y, cr, cb = cv2.split(ycrcb)
    y_eq = cv2.equalizeHist(y)
    ycrcb_eq = cv2.merge([y_eq, cr, cb])
    return cv2.cvtColor(ycrcb_eq, cv2.COLOR_YCrCb2BGR)

# ---------- Show Images ----------
def show_images(img, titles, title="Comparison"):
    assert len(img) == 3 and len(titles) == 3
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    fig.suptitle(title, fontsize=14)
    for ax, img_bgr, t in zip(axes, img, titles):
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        ax.imshow(img_rgb)
        ax.set_title(t)
        ax.axis("off")
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    img = cv2.imread("inside-the-box.jpg")
    
    ## Processing
    img_after = []
    img_after.append(mixed(img))
    img_after.append(contrast_stretch(img))
    img_after.append(global_histogram_equalization(img))

    ## Show Images
    show_images(img_after,
        ["Sol1_Adjusting Brightness and Contrast,\nCLAHE, Noise Reduction",
        "Sol2_Intensity Transformation Functions", "Sol3_Global Histogram Equalization",], title="After Processing")
    
    ## Save Image 
    cv2.imwrite("Adjusting_Brightness_Contrast_CLAHE_Denoise.png", img_after[0])
    cv2.imwrite("Intensity_Transformation_Functions.png", img_after[1])
    cv2.imwrite("Global_Histogram_Equalization.png", img_after[2])