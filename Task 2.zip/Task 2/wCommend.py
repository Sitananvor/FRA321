import cv2
import numpy as np

# Load an image from a file; OpenCV อ่านภาพเป็น BGR
img = cv2.imread("inside-the-box.jpg")


## Adjusting Brightness and Contrast
# alpha = contrast; ค่ามากกว่า 1 → contrast สูงขึ้น (ส่วนสว่างสว่างขึ้น, ส่วนมืดมืดลง) | ค่าน้อยกว่า 1 → contrast ต่ำลง (ภาพดูจืดลง)
# beta = brightness; ค่ามาก → ภาพสว่างขึ้น | ค่าลบ → ภาพมืดลง
alpha, beta = 10, 30                               
adj = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)      # Adjust the image using the formula: cv2.convertScaleAbs() = new_pixel = alpha * img + beta >> Display the adjusted image
# cv2.imshow("adjusted Image", adj)                           # Show the adjusted image


# ## Gamma Correction >> เหมาะกับการปรับภาพโดยไม่ทำให้ contrast พังในบางช่วง 
# # #Gamma Correction (normalized): output_pixel = 255 * (input_pixel / 255)^(1/gamma)  >> Lookup Table (LUT) ขนาด 256 ค่า สำหรับค่าพิกเซลตั้งแต่ 0–255
# gamma = 1.5                   # Gamma value for correction; > 1 → darkens the image, < 1 → brightens the image
# inv = 1.0 / gamma           # Inverse of gamma for the lookup table
# table = (np.linspace(0, 1, 256) ** inv * 255).astype("uint8")       # np.linspace(0, 1, 256) → สร้างตัวเลข 256 ค่า จาก 0.0 ถึง 1.0 (แทนพิกเซล normalized) >> speed
#                                                                      # ** inv → ยกกำลังด้วย 1/gamma เพื่อทำ Gamma Correction          
#                                                                      # * 255 → แปลงค่ากลับมาอยู่ในช่วง 0–255           
#                                                                      # .astype("uint8") → แปลงเป็นจำนวนเต็ม 8 บิต (0–255) สำหรับภาพ              
# gamma_img = cv2.LUT(adj, table)              # Apply the lookup table to the image using cv2.LUT()
# # cv2.imshow("adjusted Image", gamma_img)       # Show the adjusted image


## เพิ่มคอนทราสต์เฉพาะที่ด้วย CLAHE (ดีมากกับภาพย้อนแสง/หม่น)
lab = cv2.cvtColor(adj, cv2.COLOR_BGR2LAB)       # Convert the image to LAB (L = Lightness (0–100), A = สีระหว่างเขียว ↔ แดง, B = สีระหว่างน้ำเงิน ↔ เหลือง) color space for better contrast enhancement
L, A, B = cv2.split(lab)                               # Split the LAB image into 3 channels    

A = np.clip(A - 18, 0, 255)  # ลดยิ่งมาก → แดงยิ่งหาย (ลอง 5–20)

#clipLimit → จำกัดการเพิ่ม contrast เพื่อป้องกัน noise ชัดเกินไป (2.0 เป็นค่าที่นิยมใช้)
#tileGridSize → แบ่งภาพเป็น 8x8 ช่องเล็ก ๆ แล้วปรับ histogram แยกกัน → ทำให้ภาพสว่าง/contrast ดีขึ้นทั่วทั้งภาพ
clahe = cv2.createCLAHE(clipLimit=5, tileGridSize=(2,2))
L2 = clahe.apply(L)             # Apply CLAHE to the L channel (lightness) only for better contrast enhancement
lab2 = cv2.merge([L2, A.astype(np.uint8), B])    # Merge the modified L channel back with the original A and B channels
clahe_img = cv2.cvtColor(lab2, cv2.COLOR_LAB2BGR)   # Convert back to BGR color space for display
# cv2.imshow("clahe Image", clahe_img)         



# # ลดนอยส์ในภาพสี;
# dst → ตัวแปรเก็บภาพผลลัพธ์ (output image)
# h → ค่าความแรงของการลดนอยส์ (ค่ามากขึ้น → ลดนอยส์มากขึ้น แต่ภาพอาจสูญเสียรายละเอียด)
# hColor → ความแรงในการลดนอยส์ของ color components (สี) ถ้าสีเพี้ยนจากนอยส์มาก ให้เพิ่มค่านี้
# templateWindowSize → ขนาดของหน้าต่างที่ใช้ในการคำนวณนอยส์ (ขนาดเล็ก → คำนวณเร็วขึ้น แต่ลดนอยส์น้อยลง)
# searchWindowSize → ขนาดของหน้าต่างที่ใช้ในการค้นหาค่าพิกเซลที่คล้ายกัน (ขนาดเล็ก → คำนวณเร็วขึ้น แต่ลดนอยส์น้อยลง)
den_img = cv2.fastNlMeansDenoisingColored(src=clahe_img, dst=None, h=5, hColor=3, templateWindowSize=7, searchWindowSize=21)  # ปรับความแรง h ตามนอยส์
# cv2.imshow("den Image", den_img)       

cv2.imwrite("denImage.png", den_img)
# cv2.waitKey(0)                          # Wait for a key press to close the windows     
# cv2.destroyAllWindows()                 # Close all OpenCV windows