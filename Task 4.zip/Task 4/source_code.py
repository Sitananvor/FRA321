import cv2

img = cv2.imread("mega_space_molly.jpg")

## 1. Blur the original image by applying a Gaussian filter of size 5x5 with 𝜎 = 3
img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
blurred = cv2.GaussianBlur(img_rgb, (5, 5), 3)

# 2. Subtract the blurred image from the original image (mask)
mask = cv2.subtract(img_rgb, blurred)

## 3. Add the mask to the original image to create an Unsharp Masking (k = 1) and High-boost Filtering (k > 1)
# Unsharp Masking (k = 1)
k1 = 1.0
unsharp = cv2.addWeighted(img_rgb, 1.0, mask, k1, 0)

# High-boost Filtering (k > 1)
k2 = 5.0
highboost = cv2.addWeighted(img_rgb, 1.0, mask, k2, 0)

# Save the results
cv2.imwrite("unsharp.jpg", cv2.cvtColor(unsharp, cv2.COLOR_RGB2BGR))
cv2.imwrite("highboost.jpg", cv2.cvtColor(highboost, cv2.COLOR_RGB2BGR))


