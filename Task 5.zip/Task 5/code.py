import cv2, numpy as np, math

# ----------------------------- Helpers -----------------------------
def circularity(cnt: np.ndarray) -> float:     # Compute contour circularity (1.0 ~ perfectly round)
    area = cv2.contourArea(cnt)
    peri = cv2.arcLength(cnt, True)
    if peri == 0:   return 0.0
    return 4.0 * math.pi * area / (peri * peri)

def union_boxes(mask_shape, boxes, dilate_ksize=3):
    H, W = mask_shape
    mask = np.zeros((H, W), np.uint8)

    # draw all boxes onto a blank mask
    for (x, y, w, h) in boxes:
        cv2.rectangle(mask, (x, y), (x+w, y+h), 255, -1)

    # optionally dilate to fuse nearby boxes
    if dilate_ksize > 1:
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (dilate_ksize, dilate_ksize))
        mask = cv2.dilate(mask, k, iterations=1)

    # find merged boxes from contours
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return [cv2.boundingRect(c) for c in cnts]


# ----------------------------- Pipeline steps -----------------------------
def sampling1(bw: np.ndarray):
    se_close_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    return cv2.morphologyEx(bw, cv2.MORPH_CLOSE, se_close_kernel, iterations=1)     # Morphological Closing = (Dilation → Erosion) for used to remove small holes and connect broken edges

def sampling2(bw: np.ndarray):
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    dil = cv2.dilate(bw, kernel)                                                    # Dilate : expands objects (makes shapes thicker, removes small gaps/noise)
    se_close_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    return cv2.morphologyEx(dil, cv2.MORPH_CLOSE, se_close_kernel, iterations=1)    # Morphological Closing = (Dilation → Erosion)

def detect_o_from_binary(bw: np.ndarray):
    cnts, hier = cv2.findContours(bw, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)      # Find contours and hierarchyy: Outer contour (object boundary) & Inner contour (holes inside) → Used to detect shapes like 'o'
                                                                                    # Contour Shape = (N, 1, 2) 
                                                                                    # Hierarchy format: [next, prev, child, parent]
    detections = []

    for i, cnt in enumerate(cnts):
        h = hier[0][i]
        parent = h[3]
        child = h[2]
        if parent != -1 or child == -1:          # check it's an object boundary OR hole inside
            continue

        # outer contour
        x, y, w, hbox = cv2.boundingRect(cnt)    # bounding box

        # pick largest hole among children
        child_idx = child
        best_child_idx = child_idx
        best_child_area = 0.0
        while child_idx != -1:
            c_cnt = cnts[child_idx]
            a = cv2.contourArea(c_cnt)
            if a > best_child_area:
                best_child_area = a
                best_child_idx = child_idx
            child_idx = hier[0][child_idx][0]  # next sibling

        circ_i = circularity(cnts[best_child_idx]) 
        circ_o = circularity(cnt)
        # heuristics for 'o'
        if not (0.65 <= circ_o <= 1.10): 
            continue
        if not (0.55 <= circ_i <= 1.25):        
            continue

        detections.append((x, y, w, hbox))
    return detections

def visualize(img, boxes):
    vis = img.copy()
    for i, (x, y, w, h) in enumerate(boxes, start=1):
        cv2.rectangle(vis, (x, y), (x+w, y+h), (0, 255, 0), 2)      # Draw boxes
        cv2.putText(vis, f"{i}", (x, y-4), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 1, cv2.LINE_AA)    # Write number
    cv2.imwrite("Identify_o_36.png", vis)
    # cv2.imshow("Identify_o_36", vis)
    # cv2.waitKey(0)
    return vis


if __name__ == "__main__":
    # 1 Load and preprocess the image to binary
    img = cv2.imread("text_frombook.png")                   # Load the image (BGR format by default)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)            # Convert BGR (3 channels) → Grayscale (1 channel) && Output shape = (height, width)
    _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY)  # Convert Grayscale → Binary (black & white) --> simplify image for contour/OCR by keeping only black & white

    # 2 Morphology: Closing (fill small gaps) + add dilation (especially for sampling2)
    samp1, samp2  = sampling1(bw), sampling2(bw)

    # 3 Detect letter 'o'
    boxes1, boxes2 = detect_o_from_binary(samp1), detect_o_from_binary(samp2)
    # 4 Union detection boxes
    boxesU = union_boxes(gray.shape, boxes1 + boxes2, dilate_ksize=3)

    # 5 Visualize
    print(f"This image has 'o': {len(boxesU)}")
    visualize(img, boxesU)